import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";

function Addmember() {
  const [data, setdata] = useState([]);
  const [member, setMember] = useState({
    id: "",
    f_name: "",
    m_name: "",
    l_name: "",
    joning_date: "",
    mobile_number: "",
    clan_id: "",
  });

  //  GET DATA
  useEffect(() => {
    fetchdata();
  }, []);

  const fetchdata = () => {
    axios
      .get("http://localhost:4000/clan")
      .then((response) => {
        setdata(response.data);
      })
      .catch((error) => {
        console.log("get data", error);
      });
  };

  // ADD DATA
  const saveProduct = () => {
    const dataToSend = {
      id: member.id,
      f_name: member.f_name,
      m_name: member.m_name,
      l_name: member.l_name,
      joning_date: member.joning_date,
      mobile_number: member.mobile_number,
      clan_id: member.clan_id,
    };

    axios
      .post("http://localhost:4000/addmember", dataToSend)
      .then((response) => {
        if (response.status === 200) {
          window.location.reload();
        } else {
          console.log("Error:", response.data.error || "Unknown error");
        }
      })
      .catch((error) => {
        console.log("Error:", error.message || "Unknown error");
      });
  };

  return (
    <>
      <button
        type="button"
        style={{ backgroundColor: "#263043" }}
        className="btn btn-primary "
        data-bs-toggle="modal"
        data-bs-target="#exampleModal"
      >
        ADD MEMBER
      </button>
      <div
        className="modal fade "
        id="exampleModal"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content text-dark">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
                ADD MEMBER
              </h5>
              <button
                type="button"
                className="btn-close bg-white"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <form action="">
                <div className="">
                  <div className="mt-2">
                    <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                      f_name
                    </label>
                    <input
                      type="text"
                      id="title"
                      placeholder="f_name "
                      className="form-control text-center"
                      value={member.f_name}
                      onChange={(e) =>
                        setMember({ ...member, f_name: e.target.value })
                      }
                    />
                  </div>
                  <div className="mt-2">
                    <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                      m_name
                    </label>
                    <input
                      type="text"
                      id="title"
                      placeholder="m_name "
                      className="form-control text-center"
                      value={member._name}
                      onChange={(e) =>
                        setMember({ ...member, m_name: e.target.value })
                      }
                    />
                  </div>
                  <div className="mt-2">
                    <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                      l_name
                    </label>
                    <input
                      type="text"
                      id="title"
                      placeholder="l_name "
                      className="form-control text-center"
                      value={member.l_name}
                      onChange={(e) =>
                        setMember({ ...member, l_name: e.target.value })
                      }
                    />
                  </div>
                </div>
                <div className="mt-2">
                  <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                    joning_date
                  </label>
                  <input
                    type="date"
                    id="title"
                    placeholder="joning_date "
                    className="form-control text-center"
                    value={member.joning_date}
                    onChange={(e) =>
                      setMember({ ...member, joning_date: e.target.value })
                    }
                  />
                </div>
                <div className="mt-2">
                  <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                    mobile_number
                  </label>
                  <input
                    type="mobile number"
                    id="title"
                    placeholder="mobile_number"
                    className="form-control text-center"
                    value={member.mobile_number}
                    onChange={(e) =>
                      setMember({ ...member, mobile_number: e.target.value })
                    }
                  />
                </div>
                <div className="mt-3">
                  <select
                    className="form-select form-select-lg mb-3 "
                    aria-label=".form-select-lg example"
                    value={member.clan_id}
                    onChange={(e) =>
                      setMember({ ...member, clan_id: e.target.value })
                    }
                  >
                    <option value="">Select clan</option>
                    {data.map((clan) => (
                      <option key={clan.id} value={clan.id}>
                        {clan.clan_name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    data-bs-dismiss="modal"
                  >
                    Close
                  </button>
                  <button
                    type="button"
                    onClick={saveProduct}
                    data-bs-dismiss="modal"
                    className="btn btn-primary"
                  >
                    Save
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Addmember;
