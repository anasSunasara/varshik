import React, { useEffect, useState } from "react";
import axios from "axios";
import Header from "../layout/Header";
import Addmember from "./Addmember";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function Member() {
  const [data, setData] = useState([]);
  const [updatedata, setupdatedata] = useState([]);
  const [values, setValues] = useState({
    id: "",
    f_name: "",
    m_name: "",
    l_name: "",
    joning_date: new Date().toLocaleDateString(),
    mobile_number: "",
  });

  const [member, setMember] = useState({
    id: "",
    f_name: "",
    m_name: "",
    l_name: "",
    joning_date: "",
    mobile_number: "",
    clan_id: "",
  });

  // DATE FORMATE
  const formatDate = (date) => {
    if (!date) {
      return date; // Return an empty string if date is not defined or is an empty string
    }
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };

  

  // get data
  useEffect(() => {
    fetchmember();
    fetchclan();
  }, []);

  const fetchmember = () => {
    axios
      .get("http://localhost:4000/getmember")
      .then((response) => {
        setData(response.data);
        console.log(data);
      })
      .catch((error) => {
        console.log("get data", error);
      });
  };
  const fetchclan = () => {
    axios
      .get("http://localhost:4000/clan")
      .then((res) => {
        setupdatedata(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // ADD DATA
  const saveProduct = () => {
    const dataToSend = {
      id: member.id,
      f_name: member.f_name,
      m_name: member.m_name,
      l_name: member.l_name,
      joning_date: member.joning_date,
      mobile_number: member.mobile_number,
      clan_id: member.clan_id,
    };

    axios
      .post("http://localhost:4000/addmember", dataToSend)
      .then((response) => {
        fetchmember();
        if (response.status === 200) {
          // fetchmember();
          setMember({
            id:"",
            f_name: "",
            m_name: "",
            l_name: "",
            joning_date: "",
            mobile_number: "",
            clan_id: "",
          });
        } else {
          console.log("Error:", response.data.error || "Unknown error");
        }
      })
      .catch((error) => {
        console.log("Error:", error.message || "Unknown error");
        toast.warning("data don't added ")
      });
  };

  // DELETE DATA
  const handleDelete = (id) => {
    // Show a confirmation dialog before proceeding with deletion
    const isConfirmed = window.confirm(
      "Are you sure you want to delete this member?"
    );

    if (isConfirmed) {
      axios
        .delete(`http://localhost:4000/deletemember/${id}`)
        .then(() => {
          // Update the state by filtering out the deleted member
          setData((prevData) => prevData.filter((member) => member.id !== id));
        })
        .catch((error) => {
          console.log("Error deleting object:", error);
        });
    }
  };

  //EDIT DATA

  const getupdatememberData = (id) => {
    axios
      .get(`http://localhost:4000/getmemberupdateData/${id}`)
      .then((res) => {
        const formattedDate = formatDate(res.data[0].joning_date);
        console.log("Formatted Date:", formattedDate);
        setValues({
          ...res.data[0],
          joning_date: formattedDate,
        });
      })
      .catch((err) => {
        console.error("Error fetching data:", err);
      });
  };

  const handleSave = (event) => {
    event.preventDefault();
    axios
      .put(`http://localhost:4000/memberupdateData/${values.id}`, values)
      .then((res) => {
        fetchmember();
        console.log(res);
      })
      .catch((err) => {
        console.error("Error updating data:", err);
      });
  };

  return (
    <>
     <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
      />
      {/* member table */}
      <div className="container-fluid p-0">
        <Header />
        <div className="m-2">
          <button
            type="button"
            style={{ backgroundColor: "#263043" }}
            className="btn btn-primary "
            data-bs-toggle="modal"
            data-bs-target="#exampleModal"
          >
            ADD MEMBER
          </button>
        </div>
                  {/* <Addmember /> */}
        <div className="row" style={{ width: "100%" }}>
          <div>
            <div className="container pt-3" style={{ margin: "0 auto" }}>
              <table className="table">
                <thead
                  className="text-white py-5 "
                  style={{ backgroundColor: "#263043" }}
                >
                  <tr className="py-5">
                    <th>id</th>
                    <th>f_name</th>
                    <th>m_name</th>
                    <th>l_name</th>
                    <th>joning_date</th>
                    <th>mobile_number</th>
                    <th>clan name</th>
                    <th colSpan={2} className="text-center">
                      opration
                    </th>
                  </tr>
                </thead>
                {data.map((member) => (
                  <tbody style={{ backgroundColor: "#DEE1E6" }} key={member.id}>
                    <tr>
                      <td>{member.id}</td>
                      <td>{member.f_name}</td>
                      <td>{member.m_name}</td>
                      <td>{member.l_name}</td>
                      <td>{formatDate(member.joning_date)}</td>
                      <td>{member.mobile_number}</td>
                      <td>{member.clan_name}</td>

                      <td>
                        <button
                          className="btn btn-danger"
                          type="button"
                          onClick={() => handleDelete(member.id)}
                        >
                          Delete
                        </button>
                      </td>
                      <td>
                        <button
                          type="button"
                          className="btn btn-primary"
                          data-bs-toggle="modal"
                          data-bs-target="#staticBackdrop1"
                          onClick={() => {
                            getupdatememberData(member.id);
                          }}
                        >
                          Edit
                        </button>
                      </td>
                    </tr>
                  </tbody>
                ))}
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* UPDATE MODAL */}
      <div
        className="modal fade"
        id="staticBackdrop1"
        data-bs-backdrop="static"
        data-bs-keyboard="false"
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="staticBackdropLabel">
                EDIT MEMBER
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  ID{" "}
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Id..."
                  value={values.id}
                  onChange={(e) => setValues({ ...values, id: e.target.value })}
                />
              </div>

              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  First name{" "}
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Id..."
                  value={values.f_name}
                  onChange={(e) =>
                    setValues({ ...values, f_name: e.target.value })
                  }
                />
              </div>

              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  Midel name{" "}
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Id..."
                  value={values.m_name}
                  onChange={(e) =>
                    setValues({ ...values, m_name: e.target.value })
                  }
                />
              </div>
              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  Last name{" "}
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Id..."
                  value={values.l_name}
                  onChange={(e) =>
                    setValues({ ...values, l_name: e.target.value })
                  }
                />
              </div>

              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  Joining Date
                </label>
                <input
                  type="date"
                  className="form-control"
                  placeholder="Joining Date..."
                  value={formatDate(values.joning_date)}
                  onChange={(e) =>
                    setValues({ ...values, joning_date: e.target.value })
                  }
                />
              </div>

              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  Mobile_number{" "}
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Id..."
                  value={values.mobile_number}
                  onChange={(e) =>
                    setValues({ ...values, mobile_number: e.target.value })
                  }
                />
              </div>

              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  clan{" "}
                </label>
                <select
                  aria-label="Default select example"
                  className="form-select form-select-lg mb-3 "
                  placeholder="clan_id..."
                  value={values.clan_id}
                  onChange={(e) =>
                    setValues({ ...values, clan_id: e.target.value })
                  }
                >
                  {updatedata.map((clan) => (
                    <option key={clan.id} value={clan.id}>
                      {clan.clan_name}
                    </option>
                  ))}
                  <option value="3"></option>
                </select>
              </div>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Close
              </button>
              <button
                type="button"
                className="btn btn-primary"
                data-bs-dismiss="modal"
                onClick={handleSave}
              >
                Save
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ADD DATA */}
      <div
        className="modal fade "
        id="exampleModal"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content text-dark">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
                ADD MEMBER
              </h5>
              <button
                type="button"
                className="btn-close bg-white"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <form action="">
                <div className="">
                  <div className="mt-2">
                    <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                      f_name
                    </label>
                    <input
                      type="text"
                      id="title"
                      placeholder="f_name "
                      className="form-control text-center"
                      value={member.f_name}
                      onChange={(e) =>
                        setMember({ ...member, f_name: e.target.value })
                      }
                    />
                  </div>
                  <div className="mt-2">
                    <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                      m_name
                    </label>
                    <input
                      type="text"
                      id="title"
                      placeholder="m_name "
                      className="form-control text-center"
                      value={member.m_name}
                      onChange={(e) =>
                        setMember({ ...member, m_name: e.target.value })
                      }
                    />
                  </div>
                  <div className="mt-2">
                    <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                      l_name
                    </label>
                    <input
                      type="text"
                      id="title"
                      placeholder="l_name "
                      className="form-control text-center"
                      value={member.l_name}
                      onChange={(e) =>
                        setMember({ ...member, l_name: e.target.value })
                      }
                    />
                  </div>
                </div>
                <div className="mt-2">
                  <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                    joning_date
                  </label>
                  <input
                    type="date"
                    id="title"
                    placeholder="joning_date "
                    className="form-control text-center"
                    value={member.joning_date}
                    onChange={(e) =>
                      setMember({ ...member, joning_date: e.target.value })
                    }
                  />
                </div>
                <div className="mt-2">
                  <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                    mobile_number
                  </label>
                  <input
                    type="mobile number"
                    id="title"
                    placeholder="mobile_number"
                    className="form-control text-center"
                    value={member.mobile_number}
                    onChange={(e) =>
                      setMember({ ...member, mobile_number: e.target.value })
                    }
                  />
                </div>
                <div className="mt-3">
                  <select
                    className="form-select form-select-lg mb-3 "
                    aria-label=".form-select-lg example"
                    value={member.clan_id}
                    onChange={(e) =>
                      setMember({ ...member, clan_id: e.target.value })
                    }
                  >
                    <option value="">Select clan</option>
                    {updatedata.map((clan) => (
                      <option key={clan.id} value={clan.id}>
                        {clan.clan_name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    data-bs-dismiss="modal"
                  >
                    Close
                  </button>
                  <button
                    type="button"
                    onClick={saveProduct}
                    data-bs-dismiss="modal"
                    className="btn btn-primary"
                  >
                    Save
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Member;
