import { useState, useEffect } from "react";
import Header from "../layout/Header";
import Addclan from "./Addclan";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function Clan() {
  const [data, setData] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [values, setValues] = useState({
    id: "",
    clan_name: "",
  });

  // GET DATA
  useEffect(() => {
    fetchclan();
  }, [data]);

  const fetchclan = () => {
    axios
      .get("http://localhost:4000/clan")
      .then((res) => {
        setData(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // DELETE DATA
  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this record?")) {
      axios
        .delete(`http://localhost:4000/deleteclan/${id}`)
        .then(() => {
          setData((prevData) => prevData.filter((member) => member.id !== id));
          toast.success("deleted successfully");
        })
        .catch((error) => {
          console.log("Error deleting object:", error);
          toast.error("Linked with ghkg");
        });
    }
  };

  // EDIT DATA
  const getupdateData = (id) => {
    axios
      .get(`http://localhost:4000/getupdateData/${id}`)
      .then((res) => {
        setValues(res.data[0]);
        console.log(res.data[0]);
      })
      .catch((err) => {
        console.error("Error fetching data:", err);
      });
  };
  const handleSave = (event) => {
    event.preventDefault();
    axios
      .put(`http://localhost:4000/updateData/${values.id}`, values)
      .then((res) => {
        toast.success("data edit successfully");
        fetchclan();

        console.log(res);
      })
      .catch((err) => console.log(err));
  };
  
  const filteredData = data.filter((get_clan) =>
    get_clan.clan_name.toLowerCase().includes(searchQuery.toLowerCase())
  );
  return (
    <>
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
      />
      {/* Same as */}
      <ToastContainer />
      {/* clan table  */}
      <div className="container-fluid p-0">
        <Header />
        <Addclan />

        <div className="row w-100 ms-0">
          <div>
            <div className="container w-50" style={{ margin: "0 auto" }}>
              <div className="header-left d-flex me-5 mb-3" >
                <input
                  className="form-control me-2"
                  type="search"
                  placeholder="Search"
                  aria-label="Search"
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <button className="btn btn-outline-success" type="submit">
                  Search
                </button>
              </div>

              <table className="table ">
                <thead
                  className="text-white py-5 "
                  style={{ backgroundColor: "#263043" }}
                >
                  <tr className="py-5">
                    <th>id</th>
                    <th>clan</th>
                    <th>opration</th>
                  </tr>
                </thead>
                {filteredData.map((get_clan) => (
                  <tbody key={get_clan.id}>
                    <tr style={{ backgroundColor: "#DEE1E6" }}>
                      <td>{get_clan.id}</td>
                      <td>{get_clan.clan_name}</td>
                      <td>
                        <button
                          className="btn btn-danger"
                          type="button"
                          onClick={() => handleDelete(get_clan.id)}
                        >
                          {" "}
                          Delete
                        </button>{" "}
                        <button
                          type="button"
                          className="btn btn-primary"
                          data-bs-toggle="modal"
                          data-bs-target="#staticBackdrop"
                          onClick={() => {
                            getupdateData(get_clan.id);
                          }}
                        >
                          Edit
                        </button>
                      </td>
                    </tr>
                  </tbody>
                ))}
              </table>
            </div>
          </div>
        </div>
      </div>
      {/* EDIT MODAL */}
      <div
        className="modal fade"
        id="staticBackdrop"
        data-bs-backdrop="static"
        data-bs-keyboard="false"
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="staticBackdropLabel">
                EDIT CLAN
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  {" "}
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Id..."
                  value={values.id}
                  onChange={(e) => setValues({ ...values, id: e.target.value })}
                />
              </div>

              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  {" "}
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Clan Name..."
                  value={values.clan_name}
                  onChange={(e) =>
                    setValues({ ...values, clan_name: e.target.value })
                  }
                />
              </div>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Close
              </button>
              <button
                type="button"
                className="btn btn-primary"
                data-bs-dismiss="modal"
                onClick={handleSave}
              >
                Save
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Clan;
