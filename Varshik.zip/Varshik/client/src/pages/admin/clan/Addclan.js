import React, { useEffect, useState } from "react";
import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


function Addclan() {
  const [clan, setclan] = useState({
    id: "",
    clan_name: "",
  });

  const saveProduct = (e) => {
    e.preventDefault();

    // Form validation
    if (clan.clan_name === "") {
      document.getElementById("error1").innerHTML = "***Modal is empty";
      return;
    } else if (clan.clan_name.length < 3) {
      document.getElementById("error1").innerHTML =
        "Name must be at least 3 characters";
      return;
    } else {
      document.getElementById("error1").innerHTML = "";
    }

    // API call to save the clan
    axios
      .post("http://localhost:4000/addclan", { clan_name: clan.clan_name })
      .then((response) => {
        if (response.status === 200) {
          setclan({
            id: "",
            clan_name: "",
          });
          toast.success("data added successfully")
        } else {
          console.log("error:", response.data);
         
        }
        
      })
      .catch((error) => {
        console.log("Error:", error);
        toast.warning("data don't added ")

       
      });
  };

  return (
    <>
    <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
      />
      <button
        style={{ backgroundColor: "#263043" }}
        type="button"
        className="btn btn-primary m-2"
        data-bs-toggle="modal"
        data-bs-target="#exampleModal"
      >
        ADD CLAN
      </button>
      <div
        className="modal fade "
        id="exampleModal"
        tabIndex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content text-dark">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
                ADD CLAN
              </h5>
              <button
                type="button"
                className="btn-close bg-white"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <form onSubmit={saveProduct}>
                <div>
                  <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                    Clan name
                  </label>
                  <input
                    type="text"
                    name="clan_name"
                    placeholder="Clan name"
                    className="form-control text-center"
                    value={clan.clan_name}
                    onChange={(e) =>
                      setclan({ ...clan, clan_name: e.target.value })
                    }
                  />
                  <p style={{ color: "red" }} id="error1"></p>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    data-bs-dismiss="modal"
                  >
                    Close
                  </button>
                  <button
                    type="submit"
                    className="btn btn-primary"
                    data-bs-dismiss="modal"
                  >
                    Save
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Addclan;
