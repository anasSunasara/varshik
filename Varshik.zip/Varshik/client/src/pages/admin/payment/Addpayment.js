import React, { useState } from "react";
import axios from "axios";

function Addpayment() {
  const [data, setdata] = useState([]);
  const [payment, setPayment] = useState({
    Member_id: "",
    Raseed_number: "",
    book_number: "",
    payment: "",
    payment_date: "",
    payment_resiver: "",
    update_date: "",
  });
  
  //  GET DATA

  axios
    .get("http://localhost:4000/getmember")
    .then((response) => {
      setdata(response.data);
    })
    .catch((error) => {
      console.log("Error getting data:", error);
    });

  // ADD DATA
  const saveProduct = () => {
    const dataToSend = {
      Member_id: payment.Member_id,
      Raseed_number: payment.Raseed_number,
      book_number: payment.book_number,
      payment: payment.payment,
      payment_date: payment.payment_date,
      payment_resiver: payment.payment_resiver,
      update_date: payment.update_date,
    };

    axios
      .post("http://localhost:4000/addpayment", dataToSend)
      .then((response) => {
        if (response.status === 200) {
          window.location.reload();

        } else {
          console.log("Error:", response.data.error || "Unknown error");
        }
      })
      .catch((error) => {
        console.log("Error:", error.message || "Unknown error");
      });
  };

  return (
    <>
      <button
        type="button"
        style={{ backgroundColor: "#263043" }}
        className="btn btn-primary m-2"
        data-bs-toggle="modal"
        data-bs-target="#exampleModal"
      >
        ADD AMOUNT
      </button>

      <div
        className="modal fade "
        id="exampleModal"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content text-dark">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
                ADD AMOUNT
              </h5>
              <button
                type="button"
                className="btn-close bg-white"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body ">
              <div className="row ">
                <div>
                  <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                    Member
                  </label>
                  <select
                    className="form-select form-select-lg mb-3"
                    aria-label=".form-select-lg example"
                    value={payment.Member_id}
                    onChange={(e) =>
                      setPayment({ ...payment, Member_id: e.target.value })
                    }
                  >
                    <option selected>Open this select menu</option>
                    {data.map((Member) => (
                      <option key={Member.id} value={Member.id}>
                        {Member.f_name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="col-6">
                  <div>
                    <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                      Raseed number
                    </label>
                    <input
                      type="number"
                      name="Raseed_number"
                      id="title"
                      placeholder="Raseed number"
                      className="form-control text-center"
                      value={payment.Raseed_number}
                      onChange={(e) =>
                        setPayment({
                          ...payment,
                          Raseed_number: e.target.value,
                        })
                      }
                    />
                  </div>
                  <div>
                    <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                      book number
                    </label>
                    <input
                      type="number"
                      name="book_number"
                      id="title"
                      placeholder="book number "
                      className="form-control text-center"
                      value={payment.book_number}
                      onChange={(e) =>
                        setPayment({ ...payment, book_number: e.target.value })
                      }
                    />
                  </div>
                  <div className="mb-3">
                    <label
                      htmlFor="exampleFormControlInput1"
                      className="form-label"
                    >
                      Payment{" "}
                    </label>
                    <input
                      type="number"
                      className="form-control"
                      placeholder="Payment..."
                      value={payment.payment}
                      onChange={(e) =>
                        setPayment({ ...payment, payment: e.target.value })
                      }
                    />
                  </div>
                </div>
                <div className="col-6">
                  <div>
                    <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                      amount date
                    </label>
                    <input
                      type="date"
                      name="payment_date"
                      id="title"
                      placeholder="payment date"
                      className="form-control text-center"
                      value={payment.payment_date}
                      onChange={(e) =>
                        setPayment({ ...payment, payment_date: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                      amount resiver
                    </label>
                    <input
                      type="text"
                      name="payment_resiver"
                      id="title"
                      placeholder="payment_resiver"
                      className="form-control text-center"
                      value={payment.payment_resiver}
                      onChange={(e) =>
                        setPayment({
                          ...payment,
                          payment_resiver: e.target.value,
                        })
                      }
                    />
                  </div>
                  <div>
                    <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                      update_date
                    </label>
                    <input
                      type="date"
                      name="update_date"
                      id="title"
                      placeholder="update_date"
                      className="form-control text-center"
                      value={payment.update_date}
                      onChange={(e) =>
                        setPayment({ ...payment, update_date: e.target.value })
                      }
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Close
              </button>
              <button
                type="button"
                onClick={saveProduct}
                data-bs-dismiss="modal"
                className="btn btn-primary"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Addpayment;
