import React, { useState, useEffect } from "react";
import axios from "axios";
import Header from "../layout/Header";
import Addpayment from "./Addpayment";

const Payment = () => {
  const [data, setData] = useState([]);
  const [member, setMember] = useState([]);
  const [payment, setPayment] = useState({
    id: "",
    Member_id: "",
    Raseed_number: "",
    book_number: "",
    payment: "",
    payment_date: "",
    payment_resiver: "",
    update_date: "",
  });

  const [Amount, setAmount] = useState({
    Member_id: "",
    Raseed_number: "",
    book_number: "",
    payment: "",
    payment_date: "",
    payment_resiver: "",
    update_date: "",
  });

  // date formating
  const formatDate = (date) => {
    if (!date) {
      return date; // Return an empty string if date is not defined or is an empty string
    }
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };

  // GET DATA
  useEffect(() => {
    fetchdata();
    fetchmember();
  }, []);

  const fetchdata = () => {
    axios
      .get("http://localhost:4000/getpayment")
      .then((response) => {
        setData(response.data);
        console.log(data);
      })
      .catch((error) => {
        console.log("get data", error);
      });
  };

  const fetchmember = () => {
    axios
      .get("http://localhost:4000/getmember")
      .then((res) => {
        setMember(res.data);
        console.log(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // ADD DATA
  const saveProduct = () => {
    const dataToSend = {
      Member_id: Amount.Member_id,
      Raseed_number: Amount.Raseed_number,
      book_number: Amount.book_number,
      payment: Amount.payment,
      payment_date: Amount.payment_date,
      payment_resiver: Amount.payment_resiver,
      update_date: Amount.update_date,
    };

    axios
      .post("http://localhost:4000/addpayment", dataToSend)
      .then((response) => {
        if (response.status === 200) {
          fetchdata();
          setAmount({
            Member_id: "",
            Raseed_number: "",
            book_number: "",
            payment: "",
            payment_date: "",
            payment_resiver: "",
            update_date: "",
          });
          // window.location.reload();
        } else {
          console.log("Error:", response.data.error || "Unknown error");
        }
      })
      .catch((error) => {
        console.log("Error:", error.message || "Unknown error");
      });
  };
  
  // DELETE DATA
  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this record?")) {
      axios
        .delete(`http://localhost:4000/deletepayment/${id}`)
        .then(() => {
          setData((prevData) => prevData.filter((member) => member.id !== id));
        })
        .catch((error) => {
          console.log("Error deleting object:", error);
        });
    }
  };

  // EDIT DATA
  const getupdatepaymentData = (id) => {
    axios
      .get(`http://localhost:4000/getpaymentupdatedata/${id}`)
      .then((res) => {
        setPayment(res.data[0]);
        setPayment({ ...res.data[0] });
      })
      .catch((err) => {
        console.error("Error fetching data:", err);
      });
  };

  // SAVE UPDATE
  const handleSave = (event) => {
    event.preventDefault();
    axios
      .put(`http://localhost:4000/paymentupdatedata/${payment.id}`, payment)

      .then((res) => {
        fetchdata();

        console.log(res);
      })
      .catch((err) => {
        console.error("Error updating data:", err);
      });
  };

  return (
    <>
      {/* amount table */}

      <div className="container-fluid p-0">
        <Header />
        {/* <Addpayment /> */}
        <button
          type="button"
          style={{ backgroundColor: "#263043" }}
          className="btn btn-primary m-2"
          data-bs-toggle="modal"
          data-bs-target="#exampleModal"
        >
          ADD AMOUNT
        </button>
        <div className="row w-100">
          <div>
            <div className="container rounded" style={{ margin: "0 auto" }}>
              <table className="table ">
                <thead
                  className="text-white py-5 "
                  style={{ backgroundColor: "#263043" }}
                >
                  <tr className="">
                    <th className="py-3">id</th>
                    <th className="py-3">Member id</th>
                    <th className="py-3">Rseed number</th>
                    <th className="py-3">boook number</th>
                    <th className="py-3">payment </th>
                    <th className="py-3">DATE</th>
                    <th className="py-3">payment resiver</th>
                    <th className="py-3">Update date</th>
                    <th colSpan={2} className="py-3 text-center">
                      opration
                    </th>
                  </tr>
                </thead>
                {data.map((payment) => (
                  <tbody key={payment.id}>
                    <tr className="" style={{ backgroundColor: "#DEE1E6" }}>
                      <td>{payment.id}</td>
                      <td>{payment.Member_id}</td>
                      <td>{payment.Raseed_number}</td>
                      <td>{payment.book_number}</td>
                      <td>{payment.payment}</td>
                      <td>{formatDate(payment.payment_date)}</td>
                      <td>{payment.payment_resiver}</td>
                      <td>{formatDate(payment.update_date)}</td>

                      <td>
                        <button
                          className="btn btn-danger"
                          type="button"
                          onClick={() => handleDelete(payment.id)}
                        >
                          Delete
                        </button>
                      </td>
                      <td>
                        <button
                          type="button"
                          className="btn btn-primary"
                          data-bs-toggle="modal"
                          data-bs-target="#staticBackdrop1"
                          onClick={() => {
                            getupdatepaymentData(payment.id);
                          }}
                        >
                          Edit
                        </button>
                      </td>
                    </tr>
                  </tbody>
                ))}
              </table>
            </div>
          </div>
          {/* table code end */}
        </div>
      </div>

      {/* // update modal */}
      <div
        className="modal fade"
        id="staticBackdrop1"
        data-bs-backdrop="static"
        data-bs-keyboard="false"
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="staticBackdropLabel">
                EDIT AMOUNT
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>

            <div className="modal-body">
              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  ID{" "}
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Id..."
                  value={payment.id}
                  onChange={(e) =>
                    setPayment({ ...payment, id: e.target.value })
                  }
                />
              </div>

              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  Member_id{" "}
                </label>

                <select
                  aria-label="Default select example"
                  className="form-select form-select-lg mb-3 "
                  placeholder="Member_id..."
                  value={payment.Member_id}
                  onChange={(e) =>
                    setPayment({ ...payment, Member_id: e.target.value })
                  }
                >
                  {member.map((member) => (
                    <option key={member.id} value={member.id}>
                      {member.f_name}
                    </option>
                  ))}
                  <option value="3"></option>
                </select>
              </div>

              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  Raseed_number{" "}
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Raseed_number..."
                  value={payment.Raseed_number}
                  onChange={(e) =>
                    setPayment({ ...payment, Raseed_number: e.target.value })
                  }
                />
              </div>

              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  book_number{" "}
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="book_number..."
                  value={payment.book_number}
                  onChange={(e) =>
                    setPayment({ ...payment, book_number: e.target.value })
                  }
                />
              </div>

              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  payment{" "}
                </label>
                <input
                  type="number"
                  className="form-control"
                  placeholder="payment..."
                  value={payment.payment}
                  onChange={(e) =>
                    setPayment({ ...payment, payment: e.target.value })
                  }
                />
              </div>

              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  payment_date{" "}
                </label>
                {
                  <input
                    type="date"
                    className="form-control"
                    placeholder="payment_date..."
                    value={formatDate(payment.payment_date)}
                    onChange={(e) =>
                      setPayment({ ...payment, payment_date: e.target.value })
                    }
                  />
                }
              </div>

              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  payment_resiver{" "}
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="payment_resiver..."
                  value={payment.payment_resiver}
                  onChange={(e) =>
                    setPayment({ ...payment, payment_resiver: e.target.value })
                  }
                />
              </div>

              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  update_date{" "}
                </label>
                <input
                  type="date"
                  className="form-control"
                  placeholder="update_date..."
                  value={formatDate(payment.update_date)}
                  onChange={(e) =>
                    setPayment({ ...payment, update_date: e.target.value })
                  }
                />
              </div>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Close
              </button>
              <button
                type="button"
                className="btn btn-primary"
                data-bs-dismiss="modal"
                onClick={handleSave}
              >
                Save
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ADD MODAL */}
      <div
        className="modal fade "
        id="exampleModal"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content text-dark">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
                ADD AMOUNT
              </h5>
              <button
                type="button"
                className="btn-close bg-white"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body ">
              <div className="row ">
                <div>
                  <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                    Member
                  </label>
                  <select
                    className="form-select form-select-lg mb-3"
                    aria-label=".form-select-lg example"
                    value={Amount.Member_id}
                    onChange={(e) =>
                      setAmount({ ...Amount, Member_id: e.target.value })
                    }
                  >
                    <option value="">Open this select menu</option>
                    {member.map((Memberdata) => (
                      <option key={Memberdata.id} value={Memberdata.id}>
                        {Memberdata.f_name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="col-6">
                  <div>
                    <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                      Raseed number
                    </label>
                    <input
                      type="number"
                      name="Raseed_number"
                      id="title"
                      placeholder="Raseed number"
                      className="form-control text-center"
                      value={Amount.Raseed_number}
                      onChange={(e) =>
                        setAmount({
                          ...Amount,
                          Raseed_number: e.target.value,
                        })
                      }
                    />
                  </div>
                  <div>
                    <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                      book number
                    </label>
                    <input
                      type="number"
                      name="book_number"
                      id="title"
                      placeholder="book number "
                      className="form-control text-center"
                      value={Amount.book_number}
                      onChange={(e) =>
                        setAmount({ ...Amount, book_number: e.target.value })
                      }
                    />
                  </div>
                  <div className="mb-3">
                    <label
                      htmlFor="exampleFormControlInput1"
                      className="form-label"
                    >
                      Payment{" "}
                    </label>
                    <input
                      type="number"
                      className="form-control"
                      placeholder="Payment..."
                      value={Amount.payment}
                      onChange={(e) =>
                        setAmount({ ...Amount, payment: e.target.value })
                      }
                    />
                  </div>
                </div>
                <div className="col-6">
                  <div>
                    <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                      amount date
                    </label>
                    <input
                      type="date"
                      name="payment_date"
                      id="title"
                      placeholder="payment date"
                      className="form-control text-center"
                      value={Amount.payment_date}
                      onChange={(e) =>
                        setAmount({ ...Amount, payment_date: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                      amount resiver
                    </label>
                    <input
                      type="text"
                      name="payment_resiver"
                      id="title"
                      placeholder="payment_resiver"
                      className="form-control text-center"
                      value={Amount.payment_resiver}
                      onChange={(e) =>
                        setAmount({
                          ...Amount,
                          payment_resiver: e.target.value,
                        })
                      }
                    />
                  </div>
                  {/* <div>
                    <label htmlFor="title" style={{ paddingBottom: "5px" }}>
                      update_date
                    </label>
                    <input
                      type="date"
                      name="update_date"
                      id="title"
                      placeholder="update_date"
                      className="form-control text-center"
                      value={Amount.update_date}
                      onChange={(e) =>
                        setAmount({ ...Amount, update_date: e.target.value })
                      }
                    />
                  </div> */}
                </div>
              </div>
            </div>

            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Close
              </button>
              <button
                type="button"
                onClick={saveProduct}
                data-bs-dismiss="modal"
                className="btn btn-primary"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Payment;
