import React from "react";
import {
  BsFillBellFill,
  BsFillEnvelopeFill,
  BsPersonCircle,
  BsSearch,
  BsJustify,
} from "react-icons/bs";

function Header({ OpenSidebar }) {
  return (
    <header className='header ' style={{justifyContent:"space-between"}}>
    <div className='menu-icon'>
        <BsJustify className='icon' onClick={OpenSidebar}/>
    </div>
    <div className='header-left d-flex me-5'>
    <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search"/>
      <button className="btn btn-outline-success" type="submit">Search</button>
    </div>
    <div className='header-right'>
        {/* <BsFillBellFill className='icon fs-1'/>
        <BsFillEnvelopeFill className='icon fs-1'/> */}
        <div className="d-flex text-dark pt-1">
        <BsPersonCircle className='icon fs-1 '/>
        <p className="pt-2 fs-5 "> anas</p> 
        </div>
    </div>
</header>
  );
}

export default Header;
