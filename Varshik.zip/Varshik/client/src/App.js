import React from "react";
import { BrowserRouter } from "react-router-dom";
import DashboardRoute from "./routes/admin/DashboardRoute";
import ClanRoute from "./routes/admin/ClanRoute";
import Addmember_Route from "./routes/admin/Addmember_Route";
import Addpayment from "./routes/admin/Addpayment";

function App() {
  return (
    <BrowserRouter>
      <DashboardRoute />
      <ClanRoute/>
      <Addmember_Route/>
      <Addpayment/>
    </BrowserRouter>
  );
}

export default App;
