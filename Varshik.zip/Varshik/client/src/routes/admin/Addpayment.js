import React from "react";
import { Route, Routes } from "react-router-dom";
import Sidebar from "../../pages/admin/layout/Siderbar";
// import Payment from "../../pages/admin/payment/Payment";
import Payment from "../../pages/admin/payment/Payment"

function Addpayment() {
  return (
    <>
      <Routes>
        <Route
          path="/Add_payment"
          element={
            <>
              <div className="homeroute mainbackground">
                <Sidebar />
                <Payment />
              </div>
            </>
          }
        ></Route>
      </Routes>
    </>
  );
}

export default Addpayment;
