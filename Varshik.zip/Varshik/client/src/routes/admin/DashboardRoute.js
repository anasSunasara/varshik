import React, { useState } from "react";
import { Routes, Route } from "react-router-dom";
import '../../assets/css/Admin.css'
import Sidebar from '../../pages/admin/layout/Siderbar'
import Home from '../../pages/admin/layout/Home'




const DashboardRoute = () => {
  const [openSidebarToggle, setOpenSidebarToggle] = useState(false);

  const OpenSidebar = () => {
    setOpenSidebarToggle(!openSidebarToggle);
  };
  return (
    <>
      <Routes>
        <Route
          path="/dashboard"
          element={
            <div className="homeroute mainbackground">
              <Sidebar
                openSidebarToggle={openSidebarToggle}
                OpenSidebar={OpenSidebar}
              />
              <div className="grid-container">
                <Home />
              </div>
            </div>
          }
        />
      </Routes>
    </>
  );
};

export default DashboardRoute;
