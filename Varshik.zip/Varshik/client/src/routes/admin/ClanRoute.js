import React from "react";
import { Route, Routes } from "react-router-dom";
import Clan from "../../pages/admin/clan/Clan";
import Sidebar from "../../pages/admin/layout/Siderbar";

function ClanRoute() {
  return (
    <>
      <Routes>
        <Route
          path="/clan"
          element={
            <div className="homeroute mainbackground">
              <Sidebar />
                <Clan />
            </div>
          }
        ></Route>
      </Routes>
    </>
  );
}

export default ClanRoute;
