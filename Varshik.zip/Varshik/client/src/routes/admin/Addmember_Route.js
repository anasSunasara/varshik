import React from "react";
import { Route, Routes } from "react-router-dom";
import Sidebar from "../../pages/admin/layout/Siderbar";
import Member from "../../pages/admin/member/Member";

function Addmember_Route() {
  return (
    <>
      <Routes>
        <Route
          path="/Add_member"
          element={
            <>
              <div className="homeroute mainbackground">
                <Sidebar />
                <Member />
              </div>
            </>
          }
        ></Route>
      </Routes>
    </>
  );
}

export default Addmember_Route;
