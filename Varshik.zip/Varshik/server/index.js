const express = require("express");
const cors = require("cors");
const mysql = require("mysql");
const bodyParser = require("body-parser");
const multer = require('multer');
const upload = multer();


const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(upload.none());
const port = 4000;





// <---------CLAN-------->
const Clan = require("./Routes/Clan");
app.use("/", Clan);

//<--------------- ADD MEMBER
const member = require("./Routes/member");
app.use("/", member);

//<--------------- ADD payment
const payment = require("./Routes/payment");
app.use("/", payment);








app.get("/", (req, res) => {
  res.send("hello world");
});
app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
