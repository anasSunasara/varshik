const express = require("express");
const db = require("../db/Connection");

const getClanData = async (req, res) => {
  const sql = "SELECT * FROM clan";
  db.query(sql, (err, data) => {
    if (err) {
      console.error("Error executing SQL query:", err);
      return res.status(500).json({ error: "Internal Server Error" });
    }
    return res.json(data);
  });
};

const addclandata = (req, res) => {
  const { clan_name } = req.body;
  const sql = "INSERT INTO clan (clan_name) VALUES (?)";
  const data = [clan_name];

  db.query(sql, data, (err) => {
    if (err) {
      console.error("Error Adding Data", err);
      res.sendStatus(500);
    } else {
      res.sendStatus(200);
    }
  });
};

const deleteclandata = (req, res) => {
  const id = req.params.id;
  const sql = "DELETE FROM clan WHERE id = ?";

  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error("Error deleting data:", err);
      res.status(500).send("Internal Server Error");
    } else {
      console.log("Object deleted successfully");
      res.sendStatus(200);
    }
  });
};

const getupdatedata = (req, res) => {
  const id = req.params.id;
  console.log(id);
  const sql = `SELECT * FROM clan WHERE id = ${id}`;

  db.query(sql, (err, data) => {
    if (err) {
      console.error("Error fetching data by id", err);
      return res.status(500).json({ Message: "Error inside the server" });
    }
    console.log("Fetched Data:", data);
    return res.json(data);
  });
};

const Editdata = (req, res) => {
  const id = req.params.id;
  const { clan_name } = req.body;

  console.log("Received request with id:", id);
  console.log("Received request with body:", req.body);

  if (!clan_name) {
    return res.status(400).json({ error: "clan_name is required" });
  }

  const sql = 'UPDATE clan SET clan_name=? WHERE id=?';
  const data = [clan_name, id];

  console.log("Executing SQL query:", sql, "with data:", data);

  db.query(sql, data, (err, result) => {
    if (err) {
      console.error("Error updating record:", err);
      return res.status(500).json({ error: "Error updating record" });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "Record not found" });
    }

    res.sendStatus(200);
  });
};





module.exports = { getClanData, addclandata, deleteclandata, getupdatedata ,Editdata};
