const express = require("express");
const db = require("../db/Connection");

const getPaymentData = async (req, res) => {
  const sql = "SELECT * FROM add_payment";
  db.query(sql, (err, data) => {
    if (err) {
      console.error("Error executing SQL query:", err);
      return res.status(500).json({ error: "Internal Server Error" });
    }
    return res.json(data);
  });
};

const addpaymentData = (req, res) => {
  const {
    Member_id,
    Raseed_number,
    book_number,
    payment_date,
    payment_resiver,
    update_date,
    payment,
  } = req.body;
  console.log(req.body);

  console.log(req.body + "request body");

  // Correct the SQL query string
  const sql =
    "INSERT INTO add_payment (Member_id, Raseed_number, book_number, payment_date, payment_resiver, update_date, payment) VALUES (?, ?, ?, ?, ?, ?, ?)";
  const data = [
    Member_id,
    Raseed_number,
    book_number,
    payment_date,
    payment_resiver,
    update_date,
    payment,
  ];

  console.log(data + "data");

  db.query(sql, data, (err) => {
    if (err) {
      console.error("Error Adding Data", err);
      res.status(500).json({ error: "Internal Server Error" });
    } else {
      console.log("Data Added Successfully");
      res.status(200).json({ success: true });
    }
  });
};


const getpaymentUpdateData = async (req, res) => {
  const id = req.params.id;
  const sql = "SELECT * FROM add_payment WHERE id = ?";
  const data = [id];  
  console.log(data)

  db.query(sql, data, (err, result) => {
    if (err) {
      console.error("Error executing SQL query:", err);
      return res.status(500).json({ error: "Internal Server Error" });
    }

    if (result.length === 0) {
      return res.status(404).json({ error: "Member not found" });
    }

    return res.json(result);
  });
};

const paymentEditdata = (req, res) => {
  const id = req.params.id;
  const { Member_id, Raseed_number, book_number, payment, payment_date, payment_resiver, update_date } = req.body;

  console.log("Received request with id:", id);
  console.log("Received request with body:", req.body);

  if (!Member_id) {
    return res.status(400).json({ error: "Member_id is required" });
  }

  const sql = 'UPDATE add_payment SET Member_id=?, Raseed_number=?, book_number=?, payment=?, payment_date=?, payment_resiver=?,update_date=? WHERE id=?';
  const data = [Member_id, Raseed_number, book_number, payment, payment_date, payment_resiver, update_date, id];

  console.log("Executing SQL query:", sql, "with data:", data);

  db.query(sql, data, (err, result) => {
    if (err) {
      console.error("Error updating record:", err);
      return res.status(500).json({ error: "Error updating record" });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "Record not found" });
    }

    res.sendStatus(200);
  });
};


const deletepaymentdata = (req, res) => {
  const id = req.params.id;
  const sql = "DELETE FROM add_payment WHERE id = ?";

  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error("Error deleting data:", err);
      res.status(500).send("Internal Server Error");
    } else {
      console.log("Object deleted successfully");
      res.sendStatus(200);
    }
  });
};

module.exports = { getPaymentData, addpaymentData, getpaymentUpdateData ,deletepaymentdata, paymentEditdata };
