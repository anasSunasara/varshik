const express = require("express");
const db = require("../db/Connection");




const getMemberData = async (req, res) => {
  const sql = `
  SELECT add_member .*, clan.clan_name 
  FROM add_member
  INNER JOIN clan on add_member.clan_id = clan.id ;`
  db.query(sql, (err, data) => {
    if (err) {
      console.error("Error executing SQL query:", err);
      return res.status(500).json({ error: "Internal Server Error" });
    }
    return res.json(data);
  });
};

// const sql = `
// SELECT member.*, clan.clan_name
// FROM member
// INNER JOIN clan ON member.clan_id = clan.id;`


const addmemberdata=  (req,res)=>{
  console.log("reached");
  console.log(req.body);
  const { id,f_name,m_name,l_name,joning_date,mobile_number,clan_id} = req.body;
  const sql = "INSERT INTO add_member (id, f_name, m_name, l_name, joning_date, mobile_number,clan_id) VALUES (?,?,?,?,?,?,?)";
  const data = [id,f_name, m_name, l_name, joning_date, mobile_number,clan_id];

  db.query(sql, data, (err) => {
    if (err) {
      console.error("Error Adding Data", err);
      res.status(500).json({ error: "Internal Server Error" });
    } else {
      console.log("Data Added Successfully");
      res.status(200).json({ success: true });
    }
  });
}


const deletememberData = (req, res) => {
  const id = req.params.id;
  const sql = "DELETE FROM add_member WHERE id = ?";

  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error("Error deleting data:", err);
      res.status(500).send("Internal Server Error");
    } else {
      console.log("Object deleted successfully");
      res.sendStatus(200);
    }
  });
};

// server
const getmemberupdateData = async (req, res) => {
  const id = req.params.id;
  const sql = "SELECT * FROM add_member WHERE id = ?";
  const data = [id];  

  db.query(sql, data, (err, result) => {
    if (err) {
      console.error("Error executing SQL query:", err);
      return res.status(500).json({ error: "Internal Server Error" });
    }

    if (result.length === 0) {
      return res.status(404).json({ error: "Member not found" });
    }

    return res.json(result);
  });
};



const memberEditdata = (req, res) => {
  const id = req.params.id;
  const { f_name, m_name, l_name, joning_date, mobile_number, clan_id } = req.body;

  console.log("Received request with id:", id);
  console.log("Received request with body:", req.body);

  if (!f_name) {
    return res.status(400).json({ error: "f_name is required" });
  }

  const sql = 'UPDATE add_member SET f_name=?, m_name=?, l_name=?, joning_date=?, mobile_number=?, clan_id=? WHERE id=?';
  const data = [f_name, m_name, l_name, joning_date, mobile_number, clan_id, id];

  console.log("Executing SQL query:", sql, "with data:", data);

  db.query(sql, data, (err, result) => {
    if (err) {
      console.error("Error updating record:", err);
      return res.status(500).json({ error: "Error updating record" });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "Record not found" });
    }

    res.sendStatus(200);
  });
};



 module.exports = { getMemberData ,addmemberdata,deletememberData,getmemberupdateData,memberEditdata};