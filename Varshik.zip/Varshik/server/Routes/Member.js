const express = require("express");
const router = express.Router();




const member = require("../controller/member");
router.get("/getmember", member.getMemberData);
router.post("/addmember",member.addmemberdata);
router.delete("/deletemember/:id", member.deletememberData);
router.get('/getmemberupdateData/:id', member.getmemberupdateData);
router.put("/memberupdateData/:id", member.memberEditdata);


module.exports = router;