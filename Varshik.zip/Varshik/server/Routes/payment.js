const express = require("express");
const router = express.Router();

const payment = require("../controller/Payment");
router.get("/getpayment", payment.getPaymentData);
router.post("/addpayment", payment.addpaymentData);

router.get("/getpaymentupdatedata/:id", payment.getpaymentUpdateData);
router.put("/paymentupdatedata/:id", payment.paymentEditdata);

router.delete("/deletepayment/:id", payment.deletepaymentdata);


module.exports = router;