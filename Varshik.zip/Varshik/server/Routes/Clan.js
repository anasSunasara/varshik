const express = require("express");
const router = express.Router();

const Clan = require("../controller/Clan");
router.get("/clan", Clan.getClanData);
router.post("/addclan", Clan.addclandata);
router.delete("/deleteclan/:id", Clan.deleteclandata);
router.get("/getupdateData/:id", Clan.getupdatedata);
router.put("/updateData/:id", Clan.Editdata);

module.exports = router;
