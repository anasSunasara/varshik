-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2024 at 11:10 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `varshik`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_member`
--

CREATE TABLE `add_member` (
  `id` int(200) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `m_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `joning_date` date NOT NULL,
  `mobile_number` bigint(20) NOT NULL,
  `clan_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_member`
--

INSERT INTO `add_member` (`id`, `f_name`, `m_name`, `l_name`, `joning_date`, `mobile_number`, `clan_id`) VALUES
(85, 'anas', 'yasin', 'sunasara', '2023-10-13', 5678, 89),
(86, 'ahmad', 'yasin bhai', 'padarwals', '2023-10-04', 7383294925, 90),
(124, 'hashir', 'mohammad', 'mhjmjh', '2023-10-18', 456465, 90),
(149, 'dsffsd', 'fdsf', 'sfsdf', '2023-10-20', 123455454, 89),
(161, 'aaaa', 'aaa', 'aaa', '2023-12-19', 5555, 89),
(165, 'r', 'r', 'r', '0000-00-00', 55, 206),
(166, 'd', 'd', 'd', '0000-00-00', 0, 206);

-- --------------------------------------------------------

--
-- Table structure for table `add_payment`
--

CREATE TABLE `add_payment` (
  `id` int(200) NOT NULL,
  `Member_id` int(200) NOT NULL,
  `Raseed_number` int(200) NOT NULL,
  `book_number` int(200) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_resiver` varchar(20) NOT NULL,
  `update_date` date NOT NULL,
  `payment` int(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_payment`
--

INSERT INTO `add_payment` (`id`, `Member_id`, `Raseed_number`, `book_number`, `payment_date`, `payment_resiver`, `update_date`, `payment`) VALUES
(44, 86, 1, 1, '2023-10-08', 'mohammad', '2023-10-06', 2147483647),
(51, 85, 6, 555, '2023-09-27', 'anas', '2023-10-10', 6),
(55, 85, 6, 6, '2023-10-02', 'ahmad', '2023-10-01', 6666),
(56, 86, 7, 8, '2023-10-02', 'ahmad', '2023-10-01', 8),
(60, 86, 4, 4, '2023-10-17', 'anas', '2023-10-26', 2000),
(64, 86, 4, 4, '2023-10-02', 'ahmad', '0000-00-00', 444);

-- --------------------------------------------------------

--
-- Table structure for table `clan`
--

CREATE TABLE `clan` (
  `id` int(200) NOT NULL,
  `clan_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clan`
--

INSERT INTO `clan` (`id`, `clan_name`) VALUES
(89, 'sunasara'),
(90, 'padarwala'),
(178, 'kadiWala'),
(206, 'ghhg'),
(208, 'kadiwala'),
(210, 'hdd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_member`
--
ALTER TABLE `add_member`
  ADD PRIMARY KEY (`id`),
  ADD KEY `add_member_ibfk_1` (`clan_id`);

--
-- Indexes for table `add_payment`
--
ALTER TABLE `add_payment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Member_id` (`Member_id`);

--
-- Indexes for table `clan`
--
ALTER TABLE `clan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_member`
--
ALTER TABLE `add_member`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=167;

--
-- AUTO_INCREMENT for table `add_payment`
--
ALTER TABLE `add_payment`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `clan`
--
ALTER TABLE `clan`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=211;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `add_member`
--
ALTER TABLE `add_member`
  ADD CONSTRAINT `add_member_ibfk_1` FOREIGN KEY (`clan_id`) REFERENCES `clan` (`id`);

--
-- Constraints for table `add_payment`
--
ALTER TABLE `add_payment`
  ADD CONSTRAINT `add_payment_ibfk_1` FOREIGN KEY (`Member_id`) REFERENCES `add_member` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
